package br.unifor.treinamento.agenda.view.activity;

import android.content.DialogInterface;
import android.content.Intent;
import android.support.design.widget.Snackbar;
import android.support.v7.app.AlertDialog;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.util.Log;
import android.view.Menu;
import android.view.MenuInflater;
import android.view.MenuItem;
import android.widget.TextView;

import org.androidannotations.annotations.AfterViews;
import org.androidannotations.annotations.Bean;
import org.androidannotations.annotations.EActivity;
import org.androidannotations.annotations.Extra;
import org.androidannotations.annotations.ViewById;

import br.unifor.treinamento.agenda.R;
import br.unifor.treinamento.agenda.bean.Contato;
import br.unifor.treinamento.agenda.service.ContatoService;


@EActivity(R.layout.activity_detalhe_contato)
public class DetalheContatoActivity extends AppCompatActivity {

    @Bean
    ContatoService contatoService;

    private static final String TAG = "DtlContact";

    @ViewById(R.id.campo_nome)
    protected TextView campoNome;

    @ViewById(R.id.campo_telefone)
    protected TextView campoTelefone;

    @ViewById(R.id.campo_idade)
    protected TextView campoIdade;

    @Extra
    protected Integer idContato;

    private Contato contato;

    @AfterViews
    protected void afterViews() {

        contato = contatoService.getContato(idContato);

        if (contato != null) {
            campoNome.setText(contato.getNome());
            campoTelefone.setText(contato.getTelefone());
            campoIdade.setText(String.valueOf(contato.getIdade()));
        } else {
            contato = new Contato();
        }


    }

    @Override
    public boolean onCreateOptionsMenu(Menu menu) {
        MenuInflater inflater = getMenuInflater();
        inflater.inflate(R.menu.menu_detalhe_contato, menu);
        return true;
    }

    @Override
    public boolean onOptionsItemSelected(MenuItem item) {
        super.onOptionsItemSelected(item);

        switch (item.getItemId()) {
            case R.id.action_excluir:
                excluir();
                break;
            case R.id.action_salvar:
                salvar();
                break;
            default:
                Log.d(TAG, "Eu não conheço esse Menu");
                return false;

        }
        return true;
    }

    private void salvar() {

        contato.setNome(campoNome.getText().toString());
        contato.setTelefone(campoTelefone.getText().toString());
        contato.setIdade(Integer.parseInt(campoIdade.getText().toString()));

        contatoService.salvaContato(contato);


        Snackbar.make(campoNome, "Contato salvo!", Snackbar.LENGTH_SHORT).show();

    }

    private void excluir() {

        if (contato == null) {
            return;
        }

        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Atenção!!");
        builder.setMessage("Deseja apagar esse contato?");
        builder.setCancelable(false);

        builder.setPositiveButton(R.string.sim, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
                contatoService.apagaContato(contato);
                finish();
            }
        });

        builder.setNegativeButton(R.string.nao, new DialogInterface.OnClickListener() {
            @Override
            public void onClick(DialogInterface dialogInterface, int i) {
            }
        });
        builder.create().show();


    }

}
