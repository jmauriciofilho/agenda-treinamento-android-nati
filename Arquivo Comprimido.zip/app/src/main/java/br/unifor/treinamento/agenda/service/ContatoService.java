package br.unifor.treinamento.agenda.service;

import android.widget.TextView;

import org.androidannotations.annotations.EBean;

import java.util.ArrayList;
import java.util.List;

import br.unifor.treinamento.agenda.bean.Contato;
import io.realm.Realm;
import io.realm.RealmQuery;
import io.realm.RealmResults;
import io.realm.Sort;
import io.realm.annotations.RealmClass;

@EBean
public class ContatoService {

    public List<Contato> getContatos() {
        Realm realm = Realm.getDefaultInstance();
        RealmResults<Contato> contatos = realm
                .where(Contato.class)
                .findAllSorted("idade", Sort.DESCENDING);


        if (contatos != null) {
            return realm.copyFromRealm(contatos);
        } else {
            return new ArrayList<>();
        }

    }

    public Contato getContato(Integer id) {
        Realm realm = Realm.getDefaultInstance();
        Contato contato = realm
                .where(Contato.class)
                .equalTo("id", id)
                .findFirst();

        if (contato != null) {
            return realm.copyFromRealm(contato);
        } else {
            return null;
        }
    }

    public void criaContatos() {
        ArrayList<Contato> contatos = new ArrayList<Contato>();

        for (int i = 0; i < 30; i++) {
            Contato contato = new Contato();

            contato.setId(i);
            contato.setNome("Meu nome é " + i);
            contato.setIdade(i * 10);
            contato.setTelefone(Math.random() + "");

            contatos.add(contato);
        }

        Realm realm = Realm.getDefaultInstance();
        realm.beginTransaction();
        realm.copyToRealmOrUpdate(contatos);
        realm.commitTransaction();
    }


    public void salvaContato(Contato contato) {

        Realm realm = Realm.getDefaultInstance();
        realm.beginTransaction();

        if (contato.getId() == null) {
            Number max = realm.where(Contato.class).max("id");
            Integer nextId = 0;
            if (max != null) {
                nextId = max.intValue() + 1;
            }
            contato.setId(nextId);
        }
        realm.copyToRealmOrUpdate(contato);
        realm.commitTransaction();

    }

    public void apagaContato(Contato contato) {
        Realm realm = Realm.getDefaultInstance();


        Contato contatoApagar = realm
                .where(Contato.class)
                .equalTo("id", contato.getId()).findFirst();


        realm.beginTransaction();
        contatoApagar.deleteFromRealm();
        realm.commitTransaction();
    }


}
